#ifndef __TA_XOR_H__
#define __TA_XOR_H__

// {B57AA752-663C-4DBF-9E19-D36D8DBFC243}
#define XOR_TA_UUID             { 0xb57aa752, 0x663c, 0x4dbf, { 0x9e, 0x19, 0xd3, 0x6d, 0x8d, 0xbf, 0xc2, 0x43 } }

#define XOR_TA_CMD_DEFAULT      0x12340001

#if defined(__ARM_FEATURE_CMSE) && (__ARM_FEATURE_CMSE == 3)
    #include "tee_driver.h"
    extern TA_Reference g_ta_reference_xor;
#else
    int xor_test(void);
#endif

#endif /* __TA_XOR_H__ */
