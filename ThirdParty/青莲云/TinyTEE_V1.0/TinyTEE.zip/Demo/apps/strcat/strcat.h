#ifndef __TA_STRCAT_H__
#define __TA_STRCAT_H__

// {AD86A7CC-290F-403C-AADD-39413977E412}
#define STRCAT_TA_UUID          { 0xad86a7cc, 0x290f, 0x403c, { 0xaa, 0xdd, 0x39, 0x41, 0x39, 0x77, 0xe4, 0x12 } }

#define STRCAT_TA_CMD_DEFAULT   0x12340001

#if defined(__ARM_FEATURE_CMSE) && (__ARM_FEATURE_CMSE == 3)
    #include "tee_driver.h"
    extern TA_Reference g_ta_reference_strcat;
#else
    int strcat_test(void);
#endif

#endif  // __TA_STRCAT_H__
