#include <stdio.h>
#include <stdarg.h>
#include "NuMicro.h"
#include "tee_driver.h"

__NONSECURE_ENTRY
uint32_t teeDriverInvoke(uint32_t cmd, void *bufferData, size_t bufferDataLength)
{
    return teeDriverInvokeInternal(cmd, bufferData, bufferDataLength);
}

// 调试阶段可启用 TEE_Log() 函数，以显示 TEE 的 log
#if 0
void TEE_Log(const char *format, ...)
{
    va_list args;
    va_start(args, format);

    printf("[TEE] ");
    vprintf(format, args);

    va_end(args);
}
#endif
