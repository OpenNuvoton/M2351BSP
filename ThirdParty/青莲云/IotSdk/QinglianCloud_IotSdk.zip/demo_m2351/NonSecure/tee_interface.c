#include <stdio.h>
#include <stdarg.h>
#include <string.h>

// 调试阶段可启用 TEEC_Log() 函数，以显示 TEE Client 的 log
#if 0
void TEEC_Log(const char *format, ...)
{
    va_list args;
    va_start(args, format);

    printf("[TEEC] ");
    vprintf(format, args);

    va_end(args);
}
#endif
