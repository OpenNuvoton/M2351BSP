#ifndef __WIFI_MODULE_H__
#define __WIFI_MODULE_H__

/**
 * WiFi 模块初始化 (GPIO 和 UART 等配置)
 */
void wifi_module_init(void);

/**
 * WiFi 模块关闭电源后再上电
 */
int wifi_module_shutdown_and_power_on(void);

#endif  // __WIFI_MODULE_H__
